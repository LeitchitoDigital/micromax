alert('oi meu le o console meu');

let SáMerdaAí = prompt('digita nome djanho');
alert(`fala ${SáMerdaAí} ta bão?`);
console.log(`seu nome é ${SáMerdaAí}`);

let lingua = prompt('fala ai a lingua eletronica que ce mais gosta de beijar');
console.log(`ah entao ce gosta de ${lingua} tao ta`);

alert('vamo brincar de matemática');
alert('bó soma depois ve a resposta no cu');
alert('sole')
let valor1 = prompt('dijita balor un');
let valor2 = prompt('digira balor dos');
let resultadoSoma1 = valor1 + valor2;
console.log(`deu ${resultadoSoma1}`);

alert('la subtración')
let valor3 = prompt('dijita balor un');
let valor4 = prompt('digira balor dos');
let resultadoSoma2 = valor3 - valor4;
console.log(`essa deu ${resultadoSoma2}`);

alert('agora fala a idade que eu te darei uma informação inportan');
alert('te');
let idade = prompt('habla idade disgraça');
console.log(`então ce tem ${idade} que merda hein`);
//
if (idade >= 18) {
    alert('CE É MAIOR DE IDADE MANDA FOTO DA PIKA');
} else { alert('CE É DE MENOR VAI TRABALHAR FAZENDO CAMISAR PARA A SHEIN VENDE');
}

alert('me de um numeror e o compiuter dirá se é bom ou rim');
let numero = prompt('bota numero dois dijitos');
//
if (numero >= 50) {
    alert(`${numero} é bom`);
    console.log(`${numero} é bom`);
} else if (numero < 50 && numero != 42 ) {
    alert(`${numero} é rim`);
    console.log(`${numero} é rim`);
} else { 
    alert(`${numero} É A FORMATAÇAÕ NUMÉRICA DA PERFEIÇÃO CELESTIAL`);
    console.log(`You thought you might be a ghost
You thought you might be a ghost
You didn't get to Heaven, but you made it close
You didn't get to Heaven, but you made it close`);
}

let contagem = prompt('agora nós vai contar de trás pra frente no cu doita numero');
while (contagem >= 0) {
    console.log(contagem);
    contagem--
}

let nota = prompt('qual foi sua nota la prova????????????????');
if (nota > 6) {
    alert('PASOOOOOOOOO1!!!!');
    console.log(`tirase ${nota} oloko ce é brabo`);
} else if (nota < 6 && nota != 0) {
    alert('KKKKKKKKKK BICHO BURO');
    console.log(`tirase ${nota} ce nao presta memo fi`);
} else {
    alert('se mata meu');
    console.log (`nao comentarei esse ${nota}...`);
}

alert("beleza agora vamo joga o joguinho do numero secreto, diga eba se gostou");
let numeroSecreto = parseInt(Math.random() * 100 + 1);
//console.log(numeroSecreto);
let chute;
let tentações = 1;
console.log('Resultado da comparação:', chute == numeroSecreto);

while (chute != numeroSecreto) {
    chute = prompt("Digita jute");
    // yess
    if (chute == numeroSecreto) {
    break;
    }
    else {
        if (chute > numeroSecreto) {
            alert (`é menos que ${chute} bicho burro`);
        }
        else { 
            alert (`é maior que ${chute} animaw`);
        }
        //tentações == tentações + 1;
        tentações++;
    }
}

let palavraTentadora = tentações > 1 ? "tentadas" : "tentada";
alert(`acerto disgraça ${numeroSecreto} com ${tentações} ${palavraTentadora}`);

alert(`parabéns, ${SáMerdaAí}, ce completou o circuito de coisas circuitizadas do meu circu`);
alert(`ito`);
alert(`essa é a parte em que oce si mata`);
console.log('e morreu');