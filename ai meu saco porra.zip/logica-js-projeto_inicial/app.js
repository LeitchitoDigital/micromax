alert("Fala tropa, esse é o joguinho do numero secreto, diga eba se gostou");
let numeroSecreto = parseInt(Math.random() * 100 + 1);
console.log(numeroSecreto);
let chute;
let tentações = 1;
console.log('Resultado da comparação:', chute == numeroSecreto);

while (chute != numeroSecreto) {
    chute = prompt("Digita jute");
    // yess
    if (chute == numeroSecreto) {
    break;
    }
    else {
        if (chute > numeroSecreto) {
            alert (`é menos que ${chute} bicho burro`);
        }
        else { 
            alert (`é maior que ${chute} animaw`);
        }
        //tentações == tentações + 1;
        tentações++;
    }
}

let palavraTentadora = tentações > 1 ? "tentadas" : "tentada";
alert(`acerto disgraça ${numeroSecreto} com ${tentações} ${palavraTentadora}`);

//if (tentações > 1) {
//    alert(`acerto disgraça ${numeroSecreto} com ${tentações} tentadas`);
//} else { 
//    alert(`acerto disgraça ${numeroSecreto} com ${tentações} tentada`);
//}